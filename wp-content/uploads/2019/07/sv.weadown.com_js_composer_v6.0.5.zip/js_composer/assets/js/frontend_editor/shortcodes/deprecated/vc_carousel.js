(function () {
	'use strict';
	window.InlineShortcodeView_vc_carousel = window.InlineShortcodeView_vc_images_carousel.extend( {} );
})();
